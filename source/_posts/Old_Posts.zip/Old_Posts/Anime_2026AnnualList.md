---
title: '2026年度追番列表'
date: 2026-01-15 00:00:00
tags:
  - Anime
  - List
feature: true
cover: https://blogmeowwow520cn.oss-cn-beijing.aliyuncs.com/hexo/source/img/Cover/Anime_2026AnnualList.jpg
abstracts: '2026年我都追了那些番剧？'
---


## 正在撰写的文章

## 2026年度追番列表
\*本列表中 “**观看频率**” 有些为详细值，一些为估计范围。其中 `xx+` 为大于 xx 次几个的次数；`x，x` 为 x 或 x 次；`0` 为我认为触及到我的雷点，中途退坑。
| 序号 | 番剧 | 类型 | 评分 | Link | 观看频率 |
| ---- | ---- | ---- | ---- | ---- | ---- |
| 000 | Slow Start | 轻百 | [GOTO](http://meowwow520.cn/post/Anime_SlowStart) | none | 1 |
| 001 | 星灵感应 | 轻百 | none | none | 1 |
| 002 | Re:Stage! Dream Days | 轻百 | none | none | 1 |
| 003 | 辉夜大小姐想让我告白 初吻不会结束 | 恋爱 | 9.9/10 | none | 1 |
| 004 | 辉夜大小姐想让我告白 通往大人的阶梯 | 恋爱 | 8/10 | none | 1 |
| 005 | 猫娘乐园 | 日常 | 7.5/10 | none | 1 |
| 006 | 超时空辉夜姬 | 真百？ | 8/10 | [GOTO](http://meowwow520.cn/post/CosmicPrincessKaguya) | 1 |
| 007 | 我的百合乃工作是也 | 百合 | none | none | 0 |



## 结语
\*本文章封面来自《星灵感应》的动画内截图？或者是同人绘画作品？如果是，抱歉我无法提供该作品的原创作者