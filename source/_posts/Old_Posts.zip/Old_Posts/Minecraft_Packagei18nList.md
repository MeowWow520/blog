---
title: 'Minecraft 整合包汉化补丁列表'
date: 2026-02-23 19:00:00
tags: 
  - Minecraft
  - Minecraft Package
  - List
cover: https://blogmeowwow520cn.oss-cn-beijing.aliyuncs.com/hexo/source/img/Cover/Minecraft_Packagei18nList.jpg
abstracts: ''
---



## 正在撰写的文章
本表更新周期为季度或年度
## Minecraft 整合包汉化补丁列表
| 整合包名称 | 游戏版本 | 下载链接 | 备注 |
| ---- | ---- | ---- | ---- |
| Cave Horror Project 1 | 1.20.1 | [Link](https://blogmeowwow520cn.oss-cn-beijing.aliyuncs.com/MCPackagei18n/Cave-Horror-Project-1-v3.1.4-i18n.zip) | 来自https://www.ningnana.top/ |

## 结语
\*本文章封面来自《今天也要来点兔子吗？》同人绘画作品，抱歉我无法提供该作品的原创作者