---
title: 'Minecraft 整合包汉化教程'
date: 2026-02-23 12:00:00
tags:
  - Minecraft
  - Minecraft Package
  - Skills
feature: false
cover: https://blogmeowwow520cn.oss-cn-beijing.aliyuncs.com/hexo/source/img/Cover/Skills_MCPackagei18n.jpg
---


**不想了解汉化补丁的作用？直接移步至汉化流程 ---> [Here](#汉化流程)**
## 前置
### 概念解释

:::tip 什么是 Minecraft 整合包？
由于每个模组都是仅有特定一个方向或主题，但有许多玩家尝试体验多个模组的游玩感受，因此会同时安装多个模组，然而，安装的模组数量变多时往往会有一些问题，如物品ID冲突或设定冲突，且不同模组同时安装时可能也会影响游戏平衡，因此出现了一个“整合包”的概念，即**一系列模组的集合**，通常也附带经过调整的配置文件等文件，要游玩的玩家可以透过直接安装整合包应用程序进行游戏而无须对模组的安装以及调校有所了解 _^1_。
:::

:::tip 什么是 I18nUpdateMod？
「简体中文资源包（Minecraft Mod Language Package）」是由「CFPAOrg」团队维护的「自动汉化资源包」，可以将一些 Mod 中的文本翻译为中文。
本 Mod 用于自动下载、更新、应用「简体中文资源包」_^2_。同时，使用 I18nUpdateMod 是一些整合包进行汉化的主流方式。
:::

:::tip 什么是版本文件夹？
在开启第三方 MC 启动器的版本隔离之后，会改变 `.minecraft` 文件夹的结构。开启版本隔离的文件夹结构为
```text
.minecraft/
└──assets/    Minecraft 的资源文件
└──libraries/    Minecraft 用到的库
└──versions/    Minecraft 的每个版本
   └──1.14.4/    版本文件夹
```
开启版本隔离后，就可以避免在加载不同版本的 MC 时，因为存档，数据包等相互影响而导致启动报错。版本文件夹一般是指 `versions` 文件夹下的单个文件目录，实例中，`1.14.4` 文件夹就是一个版本文件夹。
:::

### 汉化补丁文件夹结构
    
```text
i18n.zip/    汉化补丁压缩包
└── config    配置文件
└──mods    模组包
└──resourcepacks    汉化资源包
└──中英对照版任务    额外可选的中英对照配置文件
```
**文件夹的作用：**
- config：该文件夹存放模组的配置文件，比如设置界面某一项设置是否开启，某一种生物的 ID。
- mods：存放了 I18nUpdateMod 本身。
- resourcepacks：汉化材质，一些模组可以通过材质包进行汉化。
- 中英对照版任务：提供额外的 config 文件来使得任务列表为中英对照汉化。

**各个文件是如何做到汉化的**
任务书模组 FTBquests 使用 `.snbt` 格式的文件，文件位于 `config/ftbquests` 目录下。
其中 .snbt 存放的是类 json 格式的数组。每一个 quests 对应一个 subtitle。未汉化的 config 文件的 subtitle 的值为非中文。汉化的 .snbt 文件的 subtitle 的值被翻译为中文，在游戏中就会显示为中文。类似的还包含任务描述、奖励文本等，翻译覆盖后就变成了中文。对应的 `中英对照版任务` 其实也存放的是和 config 中一样的 .snbt 文件，只不过 subtitle 的值为“中外混杂”。还有其他的任务书模组使用了类似的原理完成汉化。

---
resourcepacks 文件夹里的汉化材质包，其核心原理是**利用了 Minecraft 的“覆盖机制”**。游戏在运行时，会按照特定的优先级去读取文件。资源包的优先级高于游戏本体和模组本身。汉化材质包就是通过在这个文件夹里建立一套“一模一样的目录结构”，把原本的英文内容“覆盖”成中文内容。绝大多数汉化材质包的工作方式。它不修改代码，只替换“字典”。比如，游戏的代码里写的是 `item.moditem.something` 在没有汉化的情况下，游戏会读取 `assets/minecraft/lang/zn_ch.json` 文件，由于该文件没有“解释” item.moditem.something 是什么，游戏会使用模组开发者使用的默认名称，显示在游戏中。但汉化材质就会在自己的 `assets/minecraft/lang/zn_ch.json` 文件中写上 `"item.moditem.something": "某物品"` 告诉游戏这个物品的中文翻译是“某物品”。而覆盖机制的作用是，优先让游戏读取靠前的资源，而非模组默认设置的。**这一特性会在后续汉化中体现。**这就像给游戏塞了一本“中文字典”，游戏查字典时，发现资源包里有中文解释，就不看原本的英文解释了 _^3_。

---
I18nUpdateMod 可以自动汉化一些模组，并把他们整理为一个汉化材质包。

## 汉化流程
了解了汉化补丁的原理，汉化一个整合包就有条不紊了。
- 下载整合包 & 汉化补丁
- 解压缩到版本文件夹
- 覆盖原有文件
- 应用材质包

### 下载整合包 & 汉化补丁
寻找汉化补丁不是本文的主要教学内容。你可以在[Minecraft 整合包汉化补丁列表丨MeowWow520's Blog](http://blog.meowwow520.cn/post/Minecraft_Packagei18nList)寻找我使用过的一些汉化补丁。

### 解压缩到版本文件夹
将下载后的汉化补丁压缩包解压缩到版本文件夹。不出意外版本文件夹目录现在是这样子的
```text
version/    
└──AnyPackage/    版本文件夹
   └──AnyPackage-X.XX.X-i18n    汉化补丁文件
      └──/
   └──assets/    资源文件夹
   └──config/    配置文件夹
      └──ftbquests/    任务模组配置文件夹
   └──mods/    模组文件夹
   └──resourcepacks/    资源包文件夹
```

:::details 你可以通过以下两种方式找到版本文件夹
**在 PCL II 启动器 中**：PCL II 启动器 –> 启动 –> 版本选择 –> 找到对应版本右键 –> 概览 –> 快捷方式 –> 版本文件夹
**在 Windows资源管理器 中**：PCL II 启动器所在目录 –> .minecraft 文件夹 –> versions 文件夹 –> 对应版本文件夹
:::

### 覆盖原有文件
1. 将汉化补丁中的 `config`、`mods` 和 `resourcepacks` 复制到版本文件夹，覆盖版本文件夹的 `config`、`mods` 和 `resourcepacks` 文件夹。在弹出的 Windows 资源管理器窗口，**选择“替换所选的文件”**。
2. (可选) 额外将 `中英对照版任务` 文件夹中的 `ftbquests` 文件夹复制到版本文件夹子目录 `config` 中，覆盖 `config` 文件夹中的 `ftbquests` 文件夹。在弹出的 Windows 资源管理器窗口，选择“替换所选的文件”。
3. 随后你可以选择删除汉化补丁文件夹

现在，版本文件夹目录是这样子的
```text
version/    
└──AnyPackage/    版本文件夹
   └──AnyPackage-X.XX.X-i18n    汉化补丁文件
      └── config/
          └──ftbquests/    
      └──mods/  
      └──resourcepacks/    
      └──中英对照版任务/    
   └──config/    配置文件夹
      └──ftbquests/    被 AnyPackage-X.XX.X-i18n 文件夹中的 ftbquests 文件夹替换
   └──mods/    新增了 I18nUpdateMod
   └──resourcepacks/    新增了汉化材质包
```

### 应用材质包
还记得吗?[#汉化补丁文件夹结构](#汉化补丁文件夹结构)中提到了**Minecraft 的“覆盖机制”**。做完上述，汉化并没有完全结束。现在，打开游戏在 **设置-->资源包** 中会多出新增的几个汉化材质包。你可以打开 `AnyPackage-X.XX.X-i18n/resourcepacks` 查看多了哪些材质包，并加载他们。确保这些汉化材质包处于其他材质包的“上面”。

**完成汉化**

## 参考 & 脚注
1. 来源于[维基百科-我的世界模组列表](https://zh.wikipedia.org/wiki/%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C%E6%A8%A1%E7%B5%84%E5%88%97%E8%A1%A8)
2. 来源于[118nUpdateMod - Minecraft Mods - CurseForge](https://www.curseforge.com/minecraft/mc-mods/i18nupdatemod)

## 结语
\*本文章封面来自Pixiv同人绘画作品，抱歉我无法提供该作品的原创作者
\*本文章一些术语由 AI 辅助完成
\*本文章并没有严格统一名词，例如文章有时会使用“汉化补丁”，有时使用“汉化包”